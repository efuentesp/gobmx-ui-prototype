module.exports = {
  files: [
    { path: require('json-loader!./tabledata/imss.json') }
  ]
}
